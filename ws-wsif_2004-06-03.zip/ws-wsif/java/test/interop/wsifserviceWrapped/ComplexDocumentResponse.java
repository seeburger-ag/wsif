/**
 * ComplexDocumentResponse.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter.
 */

package interop.wsifserviceWrapped;

public class ComplexDocumentResponse  implements java.io.Serializable {
    private interop.wsifserviceWrapped.ComplexDocument_Type complexDocument;

    public ComplexDocumentResponse() {
    }

    public interop.wsifserviceWrapped.ComplexDocument_Type getComplexDocument() {
        return complexDocument;
    }

    public void setComplexDocument(interop.wsifserviceWrapped.ComplexDocument_Type complexDocument) {
        this.complexDocument = complexDocument;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ComplexDocumentResponse)) return false;
        ComplexDocumentResponse other = (ComplexDocumentResponse) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((complexDocument==null && other.getComplexDocument()==null) || 
             (complexDocument!=null &&
              complexDocument.equals(other.getComplexDocument())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getComplexDocument() != null) {
            _hashCode += getComplexDocument().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ComplexDocumentResponse.class);

    static {
        org.apache.axis.description.FieldDesc field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("complexDocument");
        field.setXmlName(new javax.xml.namespace.QName("http://soapinterop.org/", "ComplexDocument"));
        field.setXmlType(new javax.xml.namespace.QName("http://soapinterop.org/", "ComplexDocument"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
    };

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
