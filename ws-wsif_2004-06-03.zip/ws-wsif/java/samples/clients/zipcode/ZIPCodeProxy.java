/*
 * Copyright 2002-2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of the Apache Software Foundation and was
 * originally based on software copyright (c) 2001, 2002, International
 * Business Machines, Inc., http://www.apache.org.  For more
 * information on the Apache Software Foundation, please see
 * <http://www.apache.org/>.
 */

/*
 * The Apache Software License, Version 1.1
 *
 *
 * Copyright (c) 2002 The Apache Software Foundation.  All rights 
 * reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer. 
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution,
 *    if any, must include the following acknowledgment:  
 *       "This product includes software developed by the
 *        Apache Software Foundation (http://www.apache.org/)."
 *    Alternately, this acknowledgment may appear in the software itself,
 *    if and wherever such third-party acknowledgments normally appear.
 *
 * 4. The names "WSIF" and "Apache Software Foundation" must
 *    not be used to endorse or promote products derived from this
 *    software without prior written permission. For written 
 *    permission, please contact apache@apache.org.
 *
 * 5. Products derived from this software may not be called "Apache",
 *    nor may "Apache" appear in their name, without prior written
 *    permission of the Apache Software Foundation.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE APACHE SOFTWARE FOUNDATION OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of the Apache Software Foundation and was
 * originally based on software copyright (c) 2001, 2002, International
 * Business Machines, Inc., http://www.apache.org.  For more
 * information on the Apache Software Foundation, please see
 * <http://www.apache.org/>.
 */

package clients.zipcode;

import javax.xml.namespace.QName;

import org.apache.wsif.WSIFMessage;
import org.apache.wsif.WSIFOperation;
import org.apache.wsif.WSIFPort;
import org.apache.wsif.WSIFService;
import org.apache.wsif.WSIFServiceFactory;
import org.apache.wsif.base.WSIFServiceImpl;
import org.apache.wsif.providers.soap.apachesoap.WSIFDynamicProvider_ApacheSOAP;
import org.apache.wsif.util.WSIFPluggableProviders;

/**
 * interopLabProxy
 * @generated
 */
public class ZIPCodeProxy {
    private WSIFService fieldService;

    public ShortZipCodeResponse getShortZipCodeResponse(ShortZipCode input) {
        return getShortZipCodeResponse(input, null);
    }

    public ShortZipCodeResponse getShortZipCodeResponse(
        ShortZipCode input,
        String portName) {

        try {

            WSIFPort port = null;
            if (portName != null)
                port = fieldService.getPort(portName);
            else
                port = fieldService.getPort();

            WSIFOperation operation = port.createOperation("ShortZipCode", null, null);

            WSIFMessage inputMessage = operation.createInputMessage();
            inputMessage.setName("ShortZipCodeSoapIn");

            WSIFMessage outputMessage = operation.createOutputMessage();
            outputMessage.setName("ShortZipCodeSoapOut");

            inputMessage.setObjectPart("parameters", input);

            operation.executeRequestResponseOperation(inputMessage, outputMessage, null);

            return (ShortZipCodeResponse) outputMessage.getObjectPart("parameters");

        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException(e.getMessage());
        }
    }
    /**
    * Constructor
    * @generated
    */
    public ZIPCodeProxy(String wsdl) {
        super();

        try {

            WSIFDynamicProvider_ApacheSOAP apacheSoapProvider =
                new WSIFDynamicProvider_ApacheSOAP();
            apacheSoapProvider.setPartSerializerName("clients.zipcode.LiteralSerializer");

            WSIFPluggableProviders.overrideDefaultProvider(
                "http://schemas.xmlsoap.org/wsdl/soap/",
                apacheSoapProvider);

            if (fieldService == null) {
                WSIFServiceFactory factory = WSIFServiceFactory.newInstance();
                fieldService =
                    factory.getService(
                        wsdl,
                        this.getClass().getClassLoader(),
                        "http://webservices.eraserver.net/",
                        "ZipCodeResolver",
                        "http://webservices.eraserver.net/",
                        "ZipCodeResolverSoap");
            }

            ((WSIFServiceImpl) fieldService).mapType(
                new QName("http://webservices.eraserver.net/", "ShortZipCode"),
                ShortZipCode.class);
            ((WSIFServiceImpl) fieldService).mapType(
                new QName("http://webservices.eraserver.net/", "ShortZipCodeResponse"),
                ShortZipCodeResponse.class);

            // provider reset now at end of ZIPCodeTest.doit()
            //WSIFServiceImpl.setDynamicWSIFProvider(
            //  "http://schemas.xmlsoap.org/wsdl/soap/", null);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
